package com.example.smartkb;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        float d = getResources().getDisplayMetrics().density;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding((int) (20 * d), (int) (48 * d), (int) (20 * d), (int) (20 * d));
        root.setBackgroundColor(Color.parseColor("#14161C"));

        TextView title = new TextView(this);
        title.setText("Умная клавиатура");
        title.setTextSize(24f);
        title.setTextColor(Color.WHITE);
        root.addView(title);

        TextView steps = new TextView(this);
        steps.setText("1. Включи клавиатуру в списке\n2. Выбери её как текущую\n3. Проверь в поле ниже");
        steps.setTextSize(15f);
        steps.setTextColor(Color.parseColor("#8A90A0"));
        steps.setPadding(0, (int) (12 * d), 0, (int) (12 * d));
        root.addView(steps);

        Button b1 = new Button(this);
        b1.setText("1. Включить клавиатуру");
        b1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));
            }
        });
        root.addView(b1);

        Button b2 = new Button(this);
        b2.setText("2. Выбрать клавиатуру");
        b2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).showInputMethodPicker();
            }
        });
        root.addView(b2);

        EditText et = new EditText(this);
        et.setHint("Тут проверяй…");
        et.setHintTextColor(Color.parseColor("#8A90A0"));
        et.setTextColor(Color.WHITE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = (int) (24 * d);
        root.addView(et, lp);

        setContentView(root);
    }
}
