package com.example.smartkb;

public class Palette {
    public final int panel, key, keyFn, text, muted, accent;
    public final boolean dark;

    public Palette(int panel, int key, int keyFn, int text, int muted, int accent, boolean dark) {
        this.panel = panel;
        this.key = key;
        this.keyFn = keyFn;
        this.text = text;
        this.muted = muted;
        this.accent = accent;
        this.dark = dark;
    }
}
