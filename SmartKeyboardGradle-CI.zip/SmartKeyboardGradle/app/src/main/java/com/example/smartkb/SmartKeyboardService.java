package com.example.smartkb;

import android.inputmethodservice.InputMethodService;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;

public class SmartKeyboardService extends InputMethodService implements KeyboardActions {
    private KeyboardUi ui;

    @Override
    public void onCreate() {
        super.onCreate();
        Predictor.load(this);
    }

    @Override
    public View onCreateInputView() {
        ui = new KeyboardUi(this, this);
        ui.update(before());
        return ui;
    }

    @Override
    public boolean onEvaluateFullscreenMode() {
        return false;
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        refresh();
    }

    @Override
    public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd,
                                  int candidatesStart, int candidatesEnd) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd);
        refresh();
    }

    private String before() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return "";
        CharSequence cs = ic.getTextBeforeCursor(64, 0);
        return cs == null ? "" : cs.toString();
    }

    private void refresh() {
        if (ui != null) ui.update(before());
    }

    public void onChar(String s) {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) ic.commitText(s, 1);
        refresh();
    }

    public void onBackspace() {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
        refresh();
    }

    public void onEnter() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        EditorInfo ei = getCurrentInputEditorInfo();
        int opts = ei != null ? ei.imeOptions : 0;
        int action = opts & EditorInfo.IME_MASK_ACTION;
        boolean multiline = ei != null && (ei.inputType & InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0;
        boolean noAction = (opts & EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0;
        if (!multiline && !noAction
                && action != EditorInfo.IME_ACTION_NONE
                && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action);
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
        }
        refresh();
    }

    public void onPickWord(String w) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        String prefix = Predictor.prefixOf(before());
        ic.beginBatchEdit();
        if (prefix.length() > 0) ic.deleteSurroundingText(prefix.length(), 0);
        ic.commitText(w + " ", 1);
        ic.endBatchEdit();
        refresh();
    }
}
