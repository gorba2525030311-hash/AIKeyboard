package com.example.smartkb;

public interface KeyboardActions {
    void onChar(String s);
    void onBackspace();
    void onEnter();
    void onPickWord(String w);
}
