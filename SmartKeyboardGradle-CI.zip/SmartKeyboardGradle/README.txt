Сборка:   ./gradlew assembleDebug      (или: sh gradlew assembleDebug)
APK:      app/build/outputs/apk/debug/app-debug.apk
Стек:     Gradle 6.9.4 + Android Gradle Plugin 4.2.2 (работает на Java 8)
Нужно:    Android SDK (platform android-30), ANDROID_HOME или local.properties: sdk.dir=/путь/к/sdk
Словарь:  app/src/main/assets/words.txt  ИЛИ  DictData.java

Сборка без ПК (GitHub Actions):
  1) Залей все файлы проекта в репозиторий на GitHub (папка .github обязательна;
     если не загрузилась - Add file -> Create new file, имя .github/workflows/build.yml,
     вставь содержимое из build.yml.txt)
  2) Вкладка Actions -> Build APK -> Run workflow (или просто сделай commit)
  3) После зелёной галочки: открой запуск -> Artifacts -> SmartKeyboard-apk
