package com.example.smartkb;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.ArrayList;

/** Вся панель: сверху словарь + ⚙ настройки, потом подсказки, потом клавиши. */
public class KeyboardUi extends LinearLayout {
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private Context ctx;
    private KeyboardActions actions;
    private SharedPreferences prefs;
    private int theme;
    private int accent;
    private float d;

    private KeyboardView kb;
    private TextView info, gear;
    private LinearLayout panel, suggRow;
    private TextView[] sugg = new TextView[3];
    private View[] dividers = new View[2];
    private String[] themeNames = {"Тёмная", "Светлая", "AMOLED"};
    private TextView[] themeChips = new TextView[3];
    private int[] swatchColors;
    private View[] swatches;
    private SeekBar seek;
    private ArrayList<TextView> panelLabels = new ArrayList<TextView>();
    private ArrayList<String> words = new ArrayList<String>();

    private int dp(int v) { return (int) (v * d); }

    private TextView label(String t) {
        TextView tv = new TextView(ctx);
        tv.setText(t);
        tv.setTextSize(12f);
        tv.setMinWidth(dp(56));
        panelLabels.add(tv);
        return tv;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(ctx);
        l.setOrientation(HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    public KeyboardUi(Context context, KeyboardActions a) {
        super(context);
        ctx = context;
        actions = a;
        d = getResources().getDisplayMetrics().density;
        prefs = ctx.getSharedPreferences("smartkb", Context.MODE_PRIVATE);
        theme = prefs.getInt("theme", 0);
        accent = prefs.getInt("accent", Color.parseColor("#4C8DFF"));

        String[] sw = {"#4C8DFF", "#FF5C8A", "#2ECC71", "#FFB020", "#9B6BFF", "#19C8D0", "#FF6B3D", "#E6E6E6"};
        swatchColors = new int[sw.length];
        swatches = new View[sw.length];
        for (int i = 0; i < sw.length; i++) {
            swatchColors[i] = Color.parseColor(sw[i]);
            swatches[i] = new View(ctx);
        }

        kb = new KeyboardView(ctx, a);
        info = new TextView(ctx);
        gear = new TextView(ctx);
        panel = new LinearLayout(ctx);
        suggRow = new LinearLayout(ctx);
        seek = new SeekBar(ctx);
        for (int i = 0; i < 3; i++) { sugg[i] = new TextView(ctx); themeChips[i] = new TextView(ctx); }
        for (int i = 0; i < 2; i++) dividers[i] = new View(ctx);

        setOrientation(VERTICAL);
        setPadding(0, dp(6), 0, dp(10));

        // --- верхняя полоска: словарь + настройки ---
        LinearLayout top = new LinearLayout(ctx);
        top.setOrientation(HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(14), 0, dp(10), dp(4));
        info.setTextSize(13f);
        top.addView(info, new LinearLayout.LayoutParams(0, WRAP, 1f));
        gear.setText("⚙ Настройки");
        gear.setTextSize(13f);
        gear.setPadding(dp(10), dp(4), dp(10), dp(4));
        gear.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                panel.setVisibility(panel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            }
        });
        top.addView(gear, new LinearLayout.LayoutParams(WRAP, WRAP));
        addView(top, new LinearLayout.LayoutParams(MATCH, WRAP));

        // --- панель настроек ---
        panel.setOrientation(VERTICAL);
        panel.setPadding(dp(14), dp(4), dp(14), dp(8));
        panel.setVisibility(View.GONE);

        LinearLayout r1 = row();
        r1.addView(label("Тема"));
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView t = themeChips[i];
            t.setText(themeNames[i]);
            t.setTextSize(13f);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(12), dp(6), dp(12), dp(6));
            t.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { chooseTheme(idx); }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
            lp.rightMargin = dp(8);
            r1.addView(t, lp);
        }
        panel.addView(r1);

        LinearLayout r2 = row();
        r2.addView(label("Цвет"));
        for (int i = 0; i < swatches.length; i++) {
            final int idx = i;
            swatches[i].setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { chooseAccent(swatchColors[idx], true); }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(26), dp(26));
            lp.rightMargin = dp(6);
            r2.addView(swatches[i], lp);
        }
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp2.topMargin = dp(8);
        panel.addView(r2, lp2);

        LinearLayout r3 = row();
        r3.addView(label("Оттенок"));
        int[] cols = new int[7];
        for (int i = 0; i < 7; i++) cols[i] = Color.HSVToColor(new float[]{i * 60f, 0.7f, 1f});
        GradientDrawable rainbow = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, cols);
        rainbow.setCornerRadius(dp(5));
        FrameLayout seekWrap = new FrameLayout(ctx);
        View bar = new View(ctx);
        bar.setBackground(rainbow);
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(MATCH, dp(10), Gravity.CENTER_VERTICAL);
        blp.leftMargin = dp(12);
        blp.rightMargin = dp(12);
        seekWrap.addView(bar, blp);
        seek.setMax(360);
        seek.setProgressDrawable(new ColorDrawable(Color.TRANSPARENT));
        seek.setThumbTintList(ColorStateList.valueOf(Color.WHITE));
        seek.setSplitTrack(false);
        float[] hsv = new float[3];
        Color.colorToHSV(accent, hsv);
        seek.setProgress((int) hsv[0]);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (fromUser) chooseAccent(Color.HSVToColor(new float[]{p, 0.65f, 1f}), false);
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        seekWrap.addView(seek, new FrameLayout.LayoutParams(MATCH, dp(32)));
        r3.addView(seekWrap, new LinearLayout.LayoutParams(0, WRAP, 1f));
        LinearLayout.LayoutParams lp3 = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp3.topMargin = dp(4);
        panel.addView(r3, lp3);
        addView(panel, new LinearLayout.LayoutParams(MATCH, WRAP));

        // --- подсказки ---
        suggRow.setOrientation(HORIZONTAL);
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView tv = sugg[i];
            tv.setTextSize(17f);
            tv.setGravity(Gravity.CENTER);
            tv.setMaxLines(1);
            tv.setEllipsize(TextUtils.TruncateAt.END);
            tv.setPadding(dp(6), 0, dp(6), 0);
            tv.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if (idx < words.size()) actions.onPickWord(words.get(idx));
                }
            });
            suggRow.addView(tv, new LinearLayout.LayoutParams(0, MATCH, 1f));
            if (i < 2) {
                LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(dp(1), MATCH);
                dl.topMargin = dp(8);
                dl.bottomMargin = dp(8);
                suggRow.addView(dividers[i], dl);
            }
        }
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(MATCH, dp(40));
        sl.bottomMargin = dp(4);
        addView(suggRow, sl);

        addView(kb, new LinearLayout.LayoutParams(MATCH, WRAP));
        applyTheme();
    }

    // ---------- тема ----------
    private static int withAlpha(int c, int a) { return (c & 0x00FFFFFF) | (a << 24); }

    private Palette palette() {
        if (theme == 1) {
            return new Palette(Color.parseColor("#E9EBF0"), Color.WHITE, Color.parseColor("#CDD1DA"),
                Color.parseColor("#1B1E26"), Color.parseColor("#6B7280"), accent, false);
        } else if (theme == 2) {
            return new Palette(Color.BLACK, Color.parseColor("#1E1E1E"), Color.parseColor("#0F0F0F"),
                Color.WHITE, Color.parseColor("#8A8A8A"), accent, true);
        }
        return new Palette(Color.parseColor("#1D2029"), Color.parseColor("#3A3F4D"), Color.parseColor("#262A35"),
            Color.parseColor("#F2F4F8"), Color.parseColor("#8A90A0"), accent, true);
    }

    private int onAccentColor() {
        double lum = (0.299 * Color.red(accent) + 0.587 * Color.green(accent) + 0.114 * Color.blue(accent)) / 255.0;
        return lum > 0.6 ? Color.BLACK : Color.WHITE;
    }

    private void chooseTheme(int i) {
        theme = i;
        prefs.edit().putInt("theme", i).apply();
        applyTheme();
    }

    private void chooseAccent(int c, boolean syncSeek) {
        accent = c;
        prefs.edit().putInt("accent", c).apply();
        if (syncSeek) {
            float[] hsv = new float[3];
            Color.colorToHSV(c, hsv);
            seek.setProgress((int) hsv[0]);
        }
        applyTheme();
    }

    private void applyTheme() {
        Palette p = palette();
        float r = dp(14);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(p.panel);
        bg.setCornerRadii(new float[]{r, r, r, r, 0f, 0f, 0f, 0f});
        setBackground(bg);

        info.setTextColor(p.muted);
        gear.setTextColor(p.muted);
        GradientDrawable gb = new GradientDrawable();
        gb.setCornerRadius(dp(8));
        gb.setStroke(dp(1), withAlpha(p.muted, 0x55));
        gear.setBackground(gb);

        for (TextView t : panelLabels) t.setTextColor(p.muted);

        for (int i = 0; i < 3; i++) {
            boolean sel = i == theme;
            themeChips[i].setTextColor(sel ? onAccentColor() : p.text);
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(8));
            g.setColor(sel ? accent : withAlpha(p.text, 0x1A));
            themeChips[i].setBackground(g);
        }
        for (int i = 0; i < swatches.length; i++) {
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(swatchColors[i]);
            if (swatchColors[i] == accent) g.setStroke(dp(2), p.text);
            swatches[i].setBackground(g);
        }
        for (TextView tv : sugg) {
            tv.setTextColor(p.text);
            StateListDrawable sl = new StateListDrawable();
            sl.addState(new int[]{android.R.attr.state_pressed}, new ColorDrawable(withAlpha(p.text, 0x1A)));
            sl.addState(new int[]{}, new ColorDrawable(Color.TRANSPARENT));
            tv.setBackground(sl);
        }
        for (View v : dividers) v.setBackgroundColor(withAlpha(p.text, 0x22));
        kb.setPalette(p);
    }

    // ---------- обновление по тексту ----------
    public void update(String textBefore) {
        String prefix = Predictor.prefixOf(textBefore);
        kb.setProbs(Predictor.nextLetterProbs(prefix));
        words = Predictor.suggest(prefix, Predictor.prevWordOf(textBefore));
        for (int i = 0; i < 3; i++) {
            sugg[i].setText(i < words.size() ? words.get(i) : "");
            sugg[i].setTypeface(null, (i == 0 && prefix.length() > 0) ? Typeface.BOLD : Typeface.NORMAL);
        }
        info.setText("словарь: " + Predictor.count + " слов");
    }
}
