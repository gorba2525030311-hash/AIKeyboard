package com.example.smartkb;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/** Сама клавиатура: рисуем руками, размеры клавиш плавно меняются по вероятности буквы. */
public class KeyboardView extends View {

    static final int LETTER = 0, FN = 1, SPACE = 2;
    static final int CHAR = 0, BACK = 1, ENTER = 2;

    static class Anim {
        float cur, tgt;
        Anim(float v) { cur = v; tgt = v; }
        /** true — ещё двигается */
        boolean step(float a) {
            if (cur == tgt) return false;
            cur += (tgt - cur) * a;
            if (Math.abs(tgt - cur) < 0.002f) { cur = tgt; return false; }
            return true;
        }
    }

    static class Key {
        final String label, value;
        final int kind, act;
        final Anim grow;
        final Anim h = new Anim(1f);
        final Anim heat = new Anim(0f);
        final Anim f = new Anim(1f);
        final RectF rect = new RectF();
        Key(String label, String value, int kind, int act, float grow) {
            this.label = label; this.value = value; this.kind = kind; this.act = act;
            this.grow = new Anim(grow);
        }
    }

    static class KRow {
        final Key[] keys;
        final float padDp;
        final Anim grow;
        float top, h;
        KRow(Key[] keys, float padDp, float baseGrow) {
            this.keys = keys; this.padDp = padDp; this.grow = new Anim(baseGrow);
        }
    }

    // сила эффекта (мягкая) — как в HTML
    private static final float GROW_X = 0.8f;
    private static final float GROW_ROW = 0.35f;
    private static final float SHRINK_X = 0.75f;
    private static final float SHRINK_H = 0.72f;

    private final KeyboardActions actions;
    private final float d;
    private final KRow[] rows;
    private final Key space;
    private Palette pal;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final HashMap<Integer, Key> pressed = new HashMap<Integer, Key>();
    private final Handler repeatHandler = new Handler(Looper.getMainLooper());
    private Runnable repeater;
    private long lastNs = 0;

    public KeyboardView(Context ctx, KeyboardActions a) {
        super(ctx);
        actions = a;
        d = getResources().getDisplayMetrics().density;
        textPaint.setTextAlign(Paint.Align.CENTER);
        pal = new Palette(
            Color.parseColor("#1D2029"), Color.parseColor("#3A3F4D"), Color.parseColor("#262A35"),
            Color.parseColor("#F2F4F8"), Color.parseColor("#8A90A0"), Color.parseColor("#4C8DFF"), true);

        Key back = new Key("⌫", "", FN, BACK, 1.6f);
        space = new Key("пробел", " ", SPACE, CHAR, 5f);
        rows = new KRow[] {
            new KRow(letters("йцукенгшщзхъ", null), 1f, 1f),
            new KRow(letters("фывапролджэ", null), 6f, 1f),
            new KRow(letters("ячсмитьбю", back), 1f, 1f),
            new KRow(new Key[] {
                new Key(",", ",", FN, CHAR, 1f),
                space,
                new Key(".", ".", FN, CHAR, 1f),
                new Key("⏎", "\n", FN, ENTER, 2f)
            }, 1f, 0.9f)
        };
        repeater = new Runnable() {
            public void run() {
                actions.onBackspace();
                repeatHandler.postDelayed(this, 60);
            }
        };
    }

    private static Key[] letters(String s, Key extra) {
        int n = s.length() + (extra != null ? 1 : 0);
        Key[] ks = new Key[n];
        for (int i = 0; i < s.length(); i++) {
            String c = String.valueOf(s.charAt(i));
            ks[i] = new Key(c, c, LETTER, CHAR, 1f);
        }
        if (extra != null) ks[n - 1] = extra;
        return ks;
    }

    private float dp(float v) { return v * d; }

    public void setPalette(Palette p) { pal = p; invalidate(); }

    /** Вероятности следующей буквы -> целевые размеры/цвета клавиш. */
    public void setProbs(Map<Character, Float> probs) {
        float maxP = 0f;
        if (probs != null) {
            for (Float v : probs.values()) if (v > maxP) maxP = v;
        }
        for (int ri = 0; ri < 3; ri++) {          // только 3 буквенных ряда
            KRow r = rows[ri];
            float rowMax = 0f;
            for (Key k : r.keys) {
                if (k.kind != LETTER) continue;
                if (probs == null) {
                    k.grow.tgt = 1f; k.h.tgt = 1f; k.heat.tgt = 0f; k.f.tgt = 1f;
                    continue;
                }
                Float pf = probs.get(k.value.charAt(0));
                float p = pf == null ? 0f : pf;
                if (p > 0f) {
                    float rel = p / maxP;
                    rowMax = Math.max(rowMax, rel);
                    k.grow.tgt = 1f + GROW_X * rel * (0.4f + 0.6f * p);
                    k.h.tgt = 1f;
                    k.heat.tgt = 0.25f + 0.75f * rel;
                    k.f.tgt = 1f + 0.2f * rel;
                } else {
                    k.grow.tgt = SHRINK_X;
                    k.h.tgt = SHRINK_H;
                    k.heat.tgt = 0f;
                    k.f.tgt = 0.88f;
                }
            }
            r.grow.tgt = probs != null ? 1f + GROW_ROW * rowMax : 1f;
        }
        Float psf = probs == null ? null : probs.get(' ');
        float ps = psf == null ? 0f : psf;
        space.grow.tgt = 5f + 3f * ps;
        space.heat.tgt = ps > 0f ? 0.3f + 0.5f * ps : 0f;
        invalidate();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), (int) dp(250f));
    }

    private void layoutKeys() {
        if (getWidth() == 0) return;
        float gap = dp(5f), rowGap = dp(6f), side = dp(4f);
        float availH = getHeight() - rowGap * (rows.length - 1);
        float sumG = 0f;
        for (KRow r : rows) sumG += r.grow.cur;
        float y = 0f;
        for (KRow r : rows) {
            float rh = availH * r.grow.cur / sumG;
            r.top = y; r.h = rh;
            float left = side + dp(r.padDp);
            float right = getWidth() - left;
            float availW = (right - left) - gap * (r.keys.length - 1);
            float sumK = 0f;
            for (Key k : r.keys) sumK += k.grow.cur;
            float x = left;
            for (Key k : r.keys) {
                float kw = availW * k.grow.cur / sumK;
                float kh = rh * k.h.cur;
                float ky = y + (rh - kh) / 2f;
                k.rect.set(x, ky, x + kw, ky + kh);
                x += kw + gap;
            }
            y += rh + rowGap;
        }
    }

    private static int mix(int a, int b, float t) {
        int r = Color.red(a) + (int) ((Color.red(b) - Color.red(a)) * t);
        int g = Color.green(a) + (int) ((Color.green(b) - Color.green(a)) * t);
        int bl = Color.blue(a) + (int) ((Color.blue(b) - Color.blue(a)) * t);
        return Color.rgb(r, g, bl);
    }

    @Override
    protected void onDraw(Canvas c) {
        long now = System.nanoTime();
        float dt = lastNs == 0 ? 0.016f : Math.min(0.05f, (now - lastNs) / 1e9f);
        lastNs = now;
        float a = 1f - (float) Math.exp(-dt / 0.07f);

        boolean moving = false;
        for (KRow r : rows) {
            if (r.grow.step(a)) moving = true;
            for (Key k : r.keys) {
                if (k.grow.step(a)) moving = true;
                if (k.h.step(a)) moving = true;
                if (k.heat.step(a)) moving = true;
                if (k.f.step(a)) moving = true;
            }
        }
        layoutKeys();

        Palette p = pal;
        float rad = dp(7f);
        int shadow = p.dark ? 0x66000000 : 0x33000000;
        int pressOverlay = p.dark ? 0x33FFFFFF : 0x22000000;

        for (KRow r : rows) {
            for (Key k : r.keys) {
                int base = k.kind == FN ? p.keyFn : p.key;
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(shadow);
                c.drawRoundRect(new RectF(k.rect.left, k.rect.top + dp(1f), k.rect.right, k.rect.bottom + dp(1f)), rad, rad, paint);
                float heat = Math.max(0f, Math.min(1f, k.heat.cur * 0.7f));
                paint.setColor(mix(base, p.accent, heat));
                c.drawRoundRect(k.rect, rad, rad, paint);
                if (pressed.containsValue(k)) {
                    paint.setColor(pressOverlay);
                    c.drawRoundRect(k.rect, rad, rad, paint);
                }
                if (k.kind == SPACE) {
                    textPaint.setColor(p.muted);
                    textPaint.setTextSize(dp(15f));
                } else {
                    textPaint.setColor(p.text);
                    textPaint.setTextSize(dp(21f) * k.f.cur);
                }
                float ty = k.rect.centerY() - (textPaint.descent() + textPaint.ascent()) / 2f;
                c.drawText(k.label, k.rect.centerX(), ty, textPaint);
            }
        }

        if (moving) postInvalidateOnAnimation(); else lastNs = 0;
    }

    // ---------- ввод ----------
    private Key findKey(float x, float y) {
        layoutKeys();
        if (getWidth() == 0) return null;
        KRow row = rows[rows.length - 1];
        for (KRow r : rows) {
            if (y < r.top + r.h + dp(3f)) { row = r; break; }
        }
        Key best = null;
        float bestD = Float.MAX_VALUE;
        for (Key k : row.keys) {
            RectF r = k.rect;
            float dd = x < r.left ? r.left - x : (x > r.right ? x - r.right : 0f);
            if (dd < bestD) { bestD = dd; best = k; }
        }
        return best;
    }

    private void down(int id, float x, float y) {
        Key k = findKey(x, y);
        if (k == null) return;
        pressed.put(id, k);
        invalidate();
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        if (k.act == BACK) {
            actions.onBackspace();
            repeatHandler.removeCallbacks(repeater);
            repeatHandler.postDelayed(repeater, 380);
        } else if (k.act == ENTER) {
            actions.onEnter();
        } else {
            actions.onChar(k.value);
        }
    }

    private void up(int id) {
        Key k = pressed.remove(id);
        if (k != null && k.act == BACK) repeatHandler.removeCallbacks(repeater);
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                int i = e.getActionIndex();
                down(e.getPointerId(i), e.getX(i), e.getY(i));
                break;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                up(e.getPointerId(e.getActionIndex()));
                break;
            case MotionEvent.ACTION_CANCEL:
                for (Integer id : new ArrayList<Integer>(pressed.keySet())) up(id);
                break;
        }
        return true;
    }

    @Override
    protected void onDetachedFromWindow() {
        repeatHandler.removeCallbacks(repeater);
        super.onDetachedFromWindow();
    }
}
