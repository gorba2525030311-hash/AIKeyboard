package com.example.smartkb;

import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;

/** Словарь + предсказание — тот же алгоритм, что в HTML-версии. */
public class Predictor {
    private static String[] words = new String[0];   // по убыванию веса
    private static int[] weights = new int[0];
    private static HashMap<String, ArrayList<String>> next = new HashMap<String, ArrayList<String>>();
    private static boolean loaded = false;
    public static int count = 0;

    public static void load(Context ctx) {
        if (loaded) return;
        loaded = true;
        String txt = null;
        try {
            InputStream is = ctx.getAssets().open("words.txt");
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
            is.close();
            txt = new String(bos.toByteArray(), "UTF-8");
        } catch (Exception e) {
            txt = null;
        }
        if (txt == null) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < DictData.PARTS.length; i++) {
                if (i > 0) sb.append(',');
                sb.append(DictData.PARTS[i]);
            }
            txt = sb.toString();
        }
        parse(txt);
    }

    private static boolean isLow(char c) {
        return (c >= 'а' && c <= 'я') || c == 'ё';
    }

    private static boolean isCyr(char c) {
        return isLow(c) || (c >= 'А' && c <= 'Я') || c == 'Ё';
    }

    private static boolean allLow(String w) {
        for (int i = 0; i < w.length(); i++) if (!isLow(w.charAt(i))) return false;
        return true;
    }

    public static void parse(String txt) {
        if (txt.startsWith("\uFEFF")) txt = txt.substring(1);
        LinkedHashMap<String, Integer> cnt = new LinkedHashMap<String, Integer>();
        HashMap<String, ArrayList<String>> nx = new HashMap<String, ArrayList<String>>();
        String[] phrases = txt.split("[,;\\n]+");
        for (int pi = 0; pi < phrases.length; pi++) {
            String phrase = phrases[pi].trim().toLowerCase();
            if (phrase.length() == 0) continue;
            String[] parts = phrase.split("\\s+");
            ArrayList<String> ws = new ArrayList<String>();
            for (int j = 0; j < parts.length; j++) {
                if (parts[j].length() > 0 && allLow(parts[j])) ws.add(parts[j]);
            }
            for (int i = 0; i < ws.size(); i++) {
                String w = ws.get(i);
                Integer c = cnt.get(w);
                cnt.put(w, c == null ? 1 : c + 1);
                if (i > 0) {
                    String pw = ws.get(i - 1);
                    ArrayList<String> l = nx.get(pw);
                    if (l == null) {
                        l = new ArrayList<String>();
                        nx.put(pw, l);
                    }
                    l.add(w);
                }
            }
        }
        ArrayList<Map.Entry<String, Integer>> es = new ArrayList<Map.Entry<String, Integer>>(cnt.entrySet());
        Collections.sort(es, new Comparator<Map.Entry<String, Integer>>() {
            public int compare(Map.Entry<String, Integer> a, Map.Entry<String, Integer> b) {
                return b.getValue() - a.getValue();
            }
        });
        words = new String[es.size()];
        weights = new int[es.size()];
        for (int i = 0; i < es.size(); i++) {
            words[i] = es.get(i).getKey();
            weights[i] = es.get(i).getValue();
        }
        next = nx;
        count = words.length;
    }

    /** Буквы в конце текста (текущее недописанное слово), в нижнем регистре. */
    public static String prefixOf(String t) {
        int i = t.length();
        while (i > 0 && isCyr(t.charAt(i - 1))) i--;
        return t.substring(i).toLowerCase();
    }

    /** Предыдущее слово (перед текущим префиксом, разделённое только пробелами). */
    public static String prevWordOf(String t) {
        int j = t.length() - prefixOf(t).length();
        while (j > 0 && Character.isWhitespace(t.charAt(j - 1))) j--;
        int i = j;
        while (i > 0 && isCyr(t.charAt(i - 1))) i--;
        return t.substring(i, j).toLowerCase();
    }

    public static HashMap<Character, Float> nextLetterProbs(String prefix) {
        HashMap<Character, Float> map = new HashMap<Character, Float>();
        float total = 0f;
        for (int i = 0; i < words.length; i++) {
            String w = words[i];
            if (!w.startsWith(prefix)) continue;
            Character c = w.length() > prefix.length() ? w.charAt(prefix.length()) : ' ';
            Float old = map.get(c);
            map.put(c, (old == null ? 0f : old) + weights[i]);
            total += weights[i];
        }
        if (total == 0f) return null;
        for (Map.Entry<Character, Float> e : map.entrySet()) e.setValue(e.getValue() / total);
        return map;
    }

    public static ArrayList<String> suggest(String prefix, String prev) {
        ArrayList<String> out = new ArrayList<String>();
        if (prefix.length() > 0) {
            for (int i = 0; i < words.length && out.size() < 3; i++) {
                if (words[i].startsWith(prefix)) out.add(words[i]);
            }
            return out;
        }
        LinkedHashSet<String> set = new LinkedHashSet<String>();
        ArrayList<String> nx = next.get(prev);
        if (nx != null) set.addAll(nx);
        for (int i = 0; i < words.length && set.size() < 3; i++) set.add(words[i]);
        for (String s : set) {
            if (out.size() >= 3) break;
            out.add(s);
        }
        return out;
    }
}
